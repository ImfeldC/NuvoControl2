﻿/**************************************************************************************************
 * 
 *   Copyright (C) $year$ by B. Limacher, C. Imfeld. All Rights Reserved. Confidential
 * 
 ***************************************************************************************************
 *
 *   Project:        NuvoControl
 *   SubProject:     $rootnamespace$
 *   Author:         $username$
 *   Creation Date:  $time$
 *   File Name:      $safeitemname$.cs
 * 
 ***************************************************************************************************
 * 
 * Revisions:
 * 1) $time$, $username$: Initial implementation.
 * 
 **************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Common.Logging;



namespace $rootnamespace$
{

    public class $safeitemname$
    {
        #region Fields

        private static ILog _log = LogManager.GetCurrentClassLogger();


        #endregion


        #region Constructors
        public $safeitemname$()
        {
        }
        #endregion


        #region Field Accessors

        #endregion
    }

}

/**************************************************************************************************
 * 
 *   Copyright (C) $year$ by B. Limacher, C. Imfeld. All Rights Reserved. Confidential
 * 
**************************************************************************************************/


